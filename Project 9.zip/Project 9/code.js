var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["8c30dba0-4241-4127-8a2e-b5c40ac5e752","4922993d-52ca-48f3-ba22-89bc029cb54b","2ada5b84-0183-4db4-8b85-2eb18bb55eda","220a29f8-c735-4bdf-acc8-d9abf37fa6b7","1891890c-640a-4b85-a2b6-27672e1c95cf","ad5235ac-1639-45e9-9f01-e2bbd50bb964"],"propsByKey":{"8c30dba0-4241-4127-8a2e-b5c40ac5e752":{"name":"kidportrait_05_1","sourceUrl":"assets/api/v1/animation-library/gamelab/03EvfUX9qjzBAO2yxqRQ5KQWDGnKJXMy/category_faces/kidportrait_05.png","frameSize":{"x":314,"y":363},"frameCount":1,"looping":true,"frameDelay":10,"version":"03EvfUX9qjzBAO2yxqRQ5KQWDGnKJXMy","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":314,"y":363},"rootRelativePath":"assets/api/v1/animation-library/gamelab/03EvfUX9qjzBAO2yxqRQ5KQWDGnKJXMy/category_faces/kidportrait_05.png"},"4922993d-52ca-48f3-ba22-89bc029cb54b":{"name":"retroaliens_07_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ZhXOzdnre5u66314c4S41rbBaLa6PEbD/category_retro/retroaliens_07.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":45,"version":"ZhXOzdnre5u66314c4S41rbBaLa6PEbD","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ZhXOzdnre5u66314c4S41rbBaLa6PEbD/category_retro/retroaliens_07.png"},"2ada5b84-0183-4db4-8b85-2eb18bb55eda":{"name":"shell_15_1","sourceUrl":null,"frameSize":{"x":400,"y":345},"frameCount":1,"looping":true,"frameDelay":12,"version":"1IkUuk7wGasUg2EouXHN8i.pdH70Yz_4","categories":["aquatic_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":345},"rootRelativePath":"assets/2ada5b84-0183-4db4-8b85-2eb18bb55eda.png"},"220a29f8-c735-4bdf-acc8-d9abf37fa6b7":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"QaZh.SsDVbsx0Hpaus6WzuIXluEFp_dR","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/220a29f8-c735-4bdf-acc8-d9abf37fa6b7.png"},"1891890c-640a-4b85-a2b6-27672e1c95cf":{"name":"blue_dress_arm_behind_1","sourceUrl":null,"frameSize":{"x":400,"y":381},"frameCount":2,"looping":true,"frameDelay":12,"version":"n2qZAufyKayFs8KjyuEVHjKRxDcH_wTL","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":762},"rootRelativePath":"assets/1891890c-640a-4b85-a2b6-27672e1c95cf.png"},"ad5235ac-1639-45e9-9f01-e2bbd50bb964":{"name":"retro_purple_burst_1","sourceUrl":"assets/api/v1/animation-library/gamelab/9s4aFFAhzDx5yIL18WhWnz..kp4ZQba1/category_retro/retro_purple_burst.png","frameSize":{"x":236,"y":237},"frameCount":1,"looping":true,"frameDelay":2,"version":"9s4aFFAhzDx5yIL18WhWnz..kp4ZQba1","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":236,"y":237},"rootRelativePath":"assets/api/v1/animation-library/gamelab/9s4aFFAhzDx5yIL18WhWnz..kp4ZQba1/category_retro/retro_purple_burst.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var girl = createSprite(200,375,20,20);
girl.shapeColor="red";

var object1 = createSprite(389,84,20,20);
object1.shapeColor="green";
var object2 = createSprite(19,167,20,20);
object2.shapeColor="blue";
var object3 = createSprite(386,273,20,20);
object3.shapeColor="pink";

var destination = createSprite(200,10,300,30);
destination.shapeColor="maroon";

object1.velocityX = 60;
object2.velocityX = 60;
object3.velocityX = 60;

var life = 0;


function draw() {
background("yellow");

createEdgeSprites();

text("Lives: " + life,200,100);
  strokeWeight(0);

girl.bounceOff(edges);
object1.bounceOff(edges);
object2.bounceOff(edges);
object3.bounceOff(edges);

if (keyDown("UP_ARROW")) {
 girl.velocityY=-3;
}

if (keyDown("DOWN_ARROW")) {
 girl.velocityY=3; 
}

if (object1.isTouching(girl) || object2.isTouching(girl) || object3.isTouching(girl)) {
 girl.x=200;
 girl.y=375;
 life++;
}

if (girl.collide(destination)) {
  background("white");
}


drawSprites();  

}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
